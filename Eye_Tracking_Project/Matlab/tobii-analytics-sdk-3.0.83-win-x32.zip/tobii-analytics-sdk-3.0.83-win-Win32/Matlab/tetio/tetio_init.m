function tetio_init()
	tetio_matlab('tetio_init');
end
