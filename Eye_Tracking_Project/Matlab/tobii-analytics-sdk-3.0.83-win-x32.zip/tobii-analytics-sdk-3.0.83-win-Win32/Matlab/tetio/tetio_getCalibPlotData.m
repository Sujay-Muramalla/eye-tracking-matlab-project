function matrix = tetio_getCalibPlotData()
	matrix = tetio_matlab('tetio_getCalibPlotData');
end
