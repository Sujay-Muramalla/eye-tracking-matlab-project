function tetio_startCalib()
	tetio_matlab('tetio_startCalib');
end
