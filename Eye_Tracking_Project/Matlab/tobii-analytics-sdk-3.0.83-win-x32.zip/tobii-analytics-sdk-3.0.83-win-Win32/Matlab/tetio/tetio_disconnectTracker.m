function tetio_disconnectTracker()
	tetio_matlab('tetio_disconnectTracker');
end
