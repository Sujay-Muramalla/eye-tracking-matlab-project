function rate = tetio_getFrameRate()
	rate = tetio_matlab('tetio_getFrameRate');
end
