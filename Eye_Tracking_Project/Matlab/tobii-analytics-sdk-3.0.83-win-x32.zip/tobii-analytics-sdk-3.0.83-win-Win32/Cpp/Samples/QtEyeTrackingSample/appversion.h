#ifndef APPVERSION_H
#define APPVERSION_H

#define VERSION_NUMBER "0.0.1"

#endif // APPVERSION_H
