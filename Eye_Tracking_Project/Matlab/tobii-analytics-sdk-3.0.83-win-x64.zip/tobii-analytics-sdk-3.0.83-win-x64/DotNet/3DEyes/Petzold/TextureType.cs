// TextureType.cs by Charles Petzold
namespace Petzold.MeshGeometries
{
    public enum TextureType
    {
        None,
        Image,
        Drawing
    }
}
