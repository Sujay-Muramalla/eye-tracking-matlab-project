function time = tetio_remoteToLocalTime(remoteTime);
	time = tetio_matlab('tetio_remoteToLocalTime', remoteTime);
end