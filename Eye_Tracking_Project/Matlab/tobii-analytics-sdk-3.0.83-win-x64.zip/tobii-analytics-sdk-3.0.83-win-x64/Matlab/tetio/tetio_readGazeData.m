function [leftEye, rightEye, timestamp, trigSignal] = tetio_readGazeData()
	[leftEye, rightEye, timestamp, trigSignal] = tetio_matlab('tetio_readGazeData');
end
