function resolution = tetio_localClockResolution()
	resolution = tetio_matlab('tetio_localClockResolution');
end
