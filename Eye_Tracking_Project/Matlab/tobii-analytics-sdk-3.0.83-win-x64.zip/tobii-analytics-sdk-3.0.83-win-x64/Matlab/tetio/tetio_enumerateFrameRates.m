function frameRates = tetio_enumerateFrameRates()
	frameRates = tetio_matlab('tetio_enumerateFrameRates');
end