function tetio_startTracking()
	tetio_matlab('tetio_startTracking');
end
