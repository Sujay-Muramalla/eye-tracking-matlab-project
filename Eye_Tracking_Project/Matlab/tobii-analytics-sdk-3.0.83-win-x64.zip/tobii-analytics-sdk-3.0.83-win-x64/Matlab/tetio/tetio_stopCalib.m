function tetio_stopCalib()
	tetio_matlab('tetio_stopCalib');
end
